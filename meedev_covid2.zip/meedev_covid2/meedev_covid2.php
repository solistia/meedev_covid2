<?php
/**
* Plugin Name: meedev covid2
* Plugin URI: ""
* Description: This is private plugin it may error if use in another environtment.
* Version: 1.0
* Author: Chalat Chomchaey
* Author URI: ""
**/
defined( 'ABSPATH' ) or die( 'No direct script access allowed.' );

function DateThai2($strDate){
    $strYear = date("Y",strtotime($strDate))+543;
    $strMonth= date("n",strtotime($strDate));
    $strDay= date("j",strtotime($strDate));
    $strHour= date("H",strtotime($strDate));
    $strMinute= date("i",strtotime($strDate));
    $strSeconds= date("s",strtotime($strDate));
    $strMonthCut = Array("","ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
    $strMonthThai=$strMonthCut[$strMonth];
    return "$strDay $strMonthThai $strYear";
}
function meedev_shorcode_covid3($atts){
    //set default shortcode
    $default = shortcode_atts(array(
        'path' => 'http://covid19.ddc.moph.go.th/api/open/timeline'
    ),$atts);

    // init curl object        
    $ch = curl_init();

    // define options
    $optArray = array(
        CURLOPT_URL => $default['path'],
        CURLOPT_RETURNTRANSFER => true
    );

    // apply those options
    curl_setopt_array($ch, $optArray);

    // execute request and get response
    $result = curl_exec($ch);
    $result = json_decode( $result, true );
    $result = end($result['Data']);

    return '<div id="covid-today"><div class="row">
                <div class="full-width">
                    <ul>
                        <li>
                            <div class="full-width">
                                <div class="licircle"></div>
                                <div><h1 class="m_head">สถานการณ์ COVID-19 ในประเทศไทย</h1>
                                <p class="m_subhead">Update ข้อมูลวันที่ '.DateThai2($result['Date']).'</p></div>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="full-width">
                    <div class="width-25">
                        <div class="circle col1">
                            <div class="padtop30">
                                <h3 class="fbold">ผู้ป่วยรายใหม่<br>วันนี้</h3>
                                <div><h2 class="inline m_num">+'.number_format($result['NewConfirmed']).'</h2><h3 class="inline left10"> ราย</h3></div>
                                <span class="flight">( '.number_format($result['NewConfirmed']).' ราย )</span>
                            </div>
                        </div>
                    </div>                
                    <div class="width-25">
                        <div class="circle col2">
                            <div class="padtop30">
                                <h3 class="fbold">หายป่วยแล้ว</h3>
                                <h3>&nbsp</h3>
                                <div><h2 class="inline m_num">'.number_format($result['Recovered']).'</h2><h3 class="inline left10"> ราย</h3></div>
                                <span class="flight">( '.number_format($result['NewRecovered']).' ราย )</span>
                            </div>      
                        </div>          
                    </div>
                    <div class="width-25">
                        <div class="circle col3">
                            <div class="padtop30">
                                <h3 class="fbold">ผู้ป่วยยืนยัน<br>สะสม</h3>
                                <div><h2 class="inline m_num">'.number_format($result['Confirmed']).'</h2><h3 class="inline left10"> ราย</h3></div>
                                <span class="flight">( +'.number_format($result['NewConfirmed']).' ราย )</span>  
                            </div> 
                        </div>             
                    </div>
                    <div class="width-25 ">
                        <div class="circle col4">
                            <div class="padtop30">
                                <h3 class="fbold">เสียชีวิต</h3>
                                <h3>&nbsp</h3>
                                <div><h2 class="inline m_num">'.number_format($result['Deaths']).'</h2><h3 class="inline left10"> ราย</h3></div>
                                <span class="flight">( +'.number_format($result['NewDeaths']).' ราย )</span>  
                            </div>   
                        </div>           
                    </div>
                </div>
            </div>';
}

add_shortcode('meedev_covid3','meedev_shorcode_covid3');

function meedev_shorcode_covid2($atts){
    //set default shortcode
    $default = shortcode_atts(array(
        'path' => 'https://corona-api.com/countries/th'
    ),$atts);

    // create curl resource
    $ch = curl_init();

    // set url
    curl_setopt($ch, CURLOPT_URL, $default['path']);

    //return the transfer as a string
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    // $output contains the output string
    $output = curl_exec($ch);

    // close curl resource to free up system resources
    curl_close($ch);       

    $result = json_decode( $output, true );


    $updated_at = $result['data']['updated_at'];
    $new_confirmed = $result['data']['today']['confirmed'];
    $confirmed = $result['data']['latest_data']['confirmed'];
    //$new_recovered = $meedevDataArray['new_recovered'];
    $recovered = $result['data']['latest_data']['recovered'];
    $new_deaths = $result['data']['today']['deaths'];
    $deaths = $result['data']['latest_data']['deaths'];

    return '<div id="covid-today"><div class="row">
                <div class="full-width">
                    <ul>
                        <li>
                            <div class="full-width">
                                <div class="licircle"></div>
                                <div><h1 class="m_head">สถานการณ์ COVID-19 ในประเทศไทย</h1>
                                <p class="m_subhead">Update ข้อมูลวันที่ '.DateThai2($updated_at).'</p></div>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="full-width">
                    <div class="width-25">
                        <div class="circle col1">
                            <div class="padtop30">
                                <h3 class="fbold">ผู้ป่วยรายใหม่<br>วันนี้</h3>
                                <div><h2 class="inline m_num">+'.number_format($new_confirmed).'</h2><h3 class="inline left10"> ราย</h3></div>
                                <span class="flight" style="color: transparent !important;">( '.number_format($new_confirmed).' ราย )</span>
                            </div>
                        </div>
                    </div>                
                    <div class="width-25">
                        <div class="circle col2">
                            <div class="padtop30">
                                <h3 class="fbold">หายป่วยแล้ว</h3>
                                <h3>&nbsp</h3>
                                <div><h2 class="inline m_num">'.number_format($recovered).'</h2><h3 class="inline left10"> ราย</h3></div>
                                <span class="flight" style="color: transparent !important;">( '.number_format($recovered).' ราย )</span>
                            </div>      
                        </div>          
                    </div>
                    <div class="width-25">
                        <div class="circle col3">
                            <div class="padtop30">
                                <h3 class="fbold">ผู้ป่วยยืนยัน<br>สะสม</h3>
                                <div><h2 class="inline m_num">'.number_format($confirmed).'</h2><h3 class="inline left10"> ราย</h3></div>
                                <span class="flight">( +'.number_format($new_confirmed).' ราย )</span>  
                            </div> 
                        </div>             
                    </div>
                    <div class="width-25 ">
                        <div class="circle col4">
                            <div class="padtop30">
                                <h3 class="fbold">เสียชีวิต</h3>
                                <h3>&nbsp</h3>
                                <div><h2 class="inline m_num">'.number_format($deaths).'</h2><h3 class="inline left10"> ราย</h3></div>
                                <span class="flight">( +'.number_format($new_deaths).' ราย )</span>  
                            </div>   
                        </div>           
                    </div>
                </div>
            </div>';
}

add_shortcode('meedev_covid2','meedev_shorcode_covid2');
/*
function meedev_shorcode_covid_map($atts){
    //set default shortcode
    $default = shortcode_atts(array(
        'path' => 'https://covid19.th-stat.com/api/open/today'
    ),$atts);

    return '<div class="block-in-body"><div class="container-fluid"><div class="row"><div class="col-xs-12 pd-0"><div id="map"></div></div></div></div></div><div class="block-modal modal fade" id="covid_info" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"><div class="block-modal-in"><div class="modal-dialog" role="document"><div class="modal-content"><div class="modal-body"><div class="block-modal-content"><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="icon-bot-close"></i></span></button><h3 class="title"></h3><div id="chart_provice"></div><div class="block-case"></div></div></div></div></div></div></div><div class="block-modal modal fade" id="covid_alert" tabindex="-1" role="dialog" aria-labelledby="myModalLabelAlert"><div class="block-modal-in"><div class="modal-dialog" role="document"><div class="modal-content"><div class="modal-body"><div class="block-modal-content"><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="icon-bot-close"></i></span></button><h3 class="title"></h3><div class="alert-box"></div></div></div></div></div></div></div>';
}

add_shortcode('meedev_covid_map','meedev_shorcode_covid_map');

function meedev_shorcode_covid_graph($atts){
    //set default shortcode
    $default = shortcode_atts(array(
        'confirmed' => 'false',
        'newconfirmed' => 'false',
        'recovered' => 'false',
        'newrecovered' => 'false',
        'hospitalized' => 'false',
        //'newhospitalized' => 'false',
        'newdeaths' => 'false',
        'deaths' => 'false'
    ),$atts);


    $label = array(
        'confirmed' => 'ผู้ป่วยสะสม',
        'newconfirmed' => 'ผู้ป่วยใหม่',
        'recovered' => 'จำนวนผู้ป่วยที่รักษาหาย',
        'newrecovered' => 'จำนวนผู้ป่วยที่รักษาหายรายวัน',
        'hospitalized' => 'จำนวนผู้ป่วยที่กำลังรักษา',
        //'newhospitalized' => 'รักษาตัวในโรงพยาบาลเพิ่ม',
        'newdeaths' => 'จำนวนผู้เสียชีวิตรายวัน',
        'deaths' => 'จำนวนผู้เสียชีวิตสะสม'
    );

    $name = array(
        'confirmed' => 'Confirmed',
        'newconfirmed' => 'NewConfirmed',
        'recovered' => 'Recovered',
        'newrecovered' => 'NewRecovered',
        'hospitalized' => 'Hospitalized',
        //'newhospitalized' => 'NewHospitalized',
        'newdeaths' => 'NewDeaths',
        'deaths' => 'Deaths'
    );

    $return = '<div id="graphdiv" style="width: 100%;"></div><div id="graphSelect">';
    foreach ($default as $key => $value) {
        if($value == 'true'){
            $return = $return.'<input type="checkbox" id="'.$name[$key].'" name="'.$name[$key].'" value="'.$name[$key].'" checked>';
        }else{
            $return = $return.'<input type="checkbox" id="'.$name[$key].'" name="'.$name[$key].'" value="'.$name[$key].'">';    
        }
        $return = $return.'<label for="'.$name[$key].'">'.$label[$key].'</label>';
    }

    $return = $return.'</div>';
    return $return;
}

add_shortcode('meedev_covid_graph','meedev_shorcode_covid_graph');
*/
function meedev_add_asset2() {
    /*
    wp_enqueue_style( 'meedev-covid-fonts-styles', plugins_url('css/fonts.css',__FILE__));
    wp_enqueue_style( 'meedev-covid-jquery-jvectormap', plugins_url('vendor/jquery-jvectormap/jquery-jvectormap-2.0.3.css',__FILE__));
    wp_enqueue_style( 'meedev-covid-kit-fontawesome', 'https://kit-free.fontawesome.com/releases/latest/css/free-v4-shims.min.css');
    wp_enqueue_style( 'meedev-covid-fontawesome-face', 'https://kit-free.fontawesome.com/releases/latest/css/free-v4-font-face.min.css');
    wp_enqueue_style( 'meedev-covid-fontawesome-min', 'https://kit-free.fontawesome.com/releases/latest/css/free.min.css');
    wp_enqueue_style( 'meedev-covid-style', plugins_url('script/covid_19/style.css',__FILE__));
    wp_enqueue_style( 'meedev-covid-leaflet', 'https://unpkg.com/leaflet@1.6.0/dist/leaflet.css');
    wp_enqueue_script( 'meedev_covid_bootstrap', plugins_url('vendor/bootstrap/js/bootstrap.min.js',__FILE__),array( 'jquery' ),false,false);
    wp_enqueue_script( 'meedev_covid_map_json', plugins_url('vendor/mapv2.json',__FILE__),array( 'jquery' ),false,false);
    wp_enqueue_script( 'meedev_covid_sweetalert2', plugins_url('vendor/sweetalert/sweetalert2.all.min.js',__FILE__),array( 'jquery' ),false,false);
    wp_enqueue_script( 'meedev_covid_moment', plugins_url('vendor/moment/moment.js',__FILE__),array( 'jquery' ),false,false);
    wp_enqueue_script( 'meedev_covid_jsdelivr', plugins_url('vendor/jsdelivr/apexcharts.js',__FILE__),array( 'jquery' ),false,false);
    wp_enqueue_script( 'meedev_covid_jvectormap', plugins_url('vendor/jquery-jvectormap/jquery-jvectormap.js',__FILE__),array( 'jquery' ),false,false);
    wp_enqueue_script( 'meedev_covid_jvectormap-th-merc', plugins_url('vendor/jquery-jvectormap/jquery-jvectormap-th-merc.js',__FILE__),array( 'jquery' ),false,false);
    wp_enqueue_script( 'meedev_covid_leaflet_js', 'https://unpkg.com/leaflet@1.6.0/dist/leaflet.js',array( 'jquery' ),false,false);
    wp_enqueue_script( 'meedev_covid_preload', plugins_url('vendor/preload.js',__FILE__),array( 'jquery' ),false,false);
    wp_enqueue_script( 'meedev_covid_main', plugins_url('vendor/main.js',__FILE__),array( 'jquery' ),false,true);
    */

    wp_enqueue_style( 'meedev-covid-graph-styles-2', plugins_url('css/dygraph.css',__FILE__));
    /*
    wp_enqueue_script( 'meedev_covid_graph_min', plugins_url('vendor/dygraph.min.js',__FILE__),array( 'jquery' ),false,false);
    wp_enqueue_script( 'meedev_covid_graph_main', plugins_url('vendor/dygraph_main.js',__FILE__),array( 'jquery' ),false,true);

    */
}

add_action( 'wp_enqueue_scripts', 'meedev_add_asset2' );

